﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Helpers
{
    public static class InfrastructureRegistrations
    {
        public static void AddEFCoreServices(this IServiceCollection services)
        {
            services.AddDbContext<DictionaryContext>(options => options.UseCosmos(
                Environment.GetEnvironmentVariable("CosmosAccountEndpoint"),
                Environment.GetEnvironmentVariable("PrimaryKey"),
                Environment.GetEnvironmentVariable("DatabaseName"),
                (options) =>
                {
                    options.ConnectionMode(ConnectionMode.Gateway);
                    options.ExecutionStrategy(dependencies => new CosmosDbContextExecutionStrategy(dependencies, 5, TimeSpan.FromSeconds(5)));
                }
            ), ServiceLifetime.Scoped);

            services.AddScoped(typeof(IModelBuilderHelper<>), typeof(ModelBuilderHelper<>));

            //RegisterResultContext<QueueDetail>(services);
            //RegisterResultContext<RuleGroupResult>(services);
            //RegisterResultContext<FutureAction>(services);
            //RegisterResultContext<Result>(services);

            //RegisterConfigRepository<RuleGroup>(services);
            //RegisterConfigRepository<Fact>(services);
            //RegisterConfigRepository<Tenant>(services);
            //RegisterConfigRepository<TenantRule>(services);
            //RegisterConfigRepository<TenantUser>(services);
            //RegisterConfigRepository<Product>(services);
            //RegisterConfigRepository<ProductModel>(services);
            //RegisterConfigRepository<Queue>(services);
            //RegisterConfigRepository<QueueUser>(services);

            //RegisterResultRepository<QueueDetail>(services);
            //RegisterResultRepository<RuleGroupResult>(services);
            //RegisterResultRepository<FutureAction>(services);
            //RegisterResultRepository<Result>(services);

            //services.AddScoped(typeof(IModelBuilderHelper<QueueDetail>), builder =>
            //{
            //    return new ModelBuilderHelper<QueueDetail>(modelBuilder => modelBuilder.Entity<QueueDetail>().OwnsMany(e => e.FactDetails));
            //});
            //services.AddScoped(typeof(IModelBuilderHelper<FutureAction>), builder =>
            //{
            //    return new ModelBuilderHelper<FutureAction>(modelBuilder => modelBuilder.Entity<FutureAction>());
            //});
            //services.AddScoped(typeof(IModelBuilderHelper<RuleGroupResult>), builder =>
            //{
            //    return new ModelBuilderHelper<RuleGroupResult>(modelBuilder => modelBuilder.Entity<RuleGroupResult>());
            //});
            //services.AddScoped(typeof(IModelBuilderHelper<Result>), builder =>
            //{
            //    return new ModelBuilderHelper<Result>(modelBuilder => modelBuilder.Entity<Result>());
            //});

            //services.TryAddSingleton<IActionContextAccessor, ActionContextAccessor>();
            //services.AddScoped<IContainerNameHelper, ContainerNameHelper>();

            //services.AddScoped(typeof(ITenantRuleRepository), builder =>
            //{
            //    return new TenantRuleRepository(builder.GetService<ConfigContext>(), builder.GetRequiredService<IRequestHeaderParametersService>());
            //});
        }

        //private static void RegisterConfigRepository<T>(IServiceCollection services) where T : BaseEntity
        //{
        //    services.AddScoped(typeof(IAsyncEFCoreRepository<T>), builder =>
        //    {
        //        return new EFCoreRepository<T>(builder.GetService<ConfigContext>(), builder.GetRequiredService<IRequestHeaderParametersService>());
        //    });
        //}

        //private static void RegisterResultRepository<T>(IServiceCollection services) where T : BaseEntity
        //{
        //    services.AddScoped(typeof(IAsyncEFCoreRepository<T>), builder =>
        //    {
        //        return new EFCoreRepository<T>(builder.GetService<ResultContext<T>>(), builder.GetRequiredService<IRequestHeaderParametersService>());
        //    });
        //}

        //private static void RegisterResultContext<T>(IServiceCollection services) where T : BaseEntity
        //{
        //    services.AddDbContext<ResultContext<T>>(options => options.UseCosmos(
        //        Environment.GetEnvironmentVariable("CosmosAccountEndpoint"),
        //        Environment.GetEnvironmentVariable("PrimaryKey"),
        //        Environment.GetEnvironmentVariable("DatabaseName"),
        //        (options) =>
        //        {
        //            options.ConnectionMode(ConnectionMode.Gateway);
        //            options.ExecutionStrategy(dependencies => new CosmosDbContextExecutionStrategy(dependencies, 5, TimeSpan.FromSeconds(5)));
        //        }
        //    ), ServiceLifetime.Scoped);
        //}
    }
}
