﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationCore.Constants
{
    class Class1
    {
    }
}
