﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Logging
{
    class Class1
    {
    }
}
