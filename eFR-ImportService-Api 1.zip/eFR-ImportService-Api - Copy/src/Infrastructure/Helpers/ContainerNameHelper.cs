﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Helpers
{
    public class ContainerNameHelper : IContainerNameHelper
    {
        private readonly IActionContextAccessor actionContextAccessor;

        public ContainerNameHelper(IActionContextAccessor actionContextAccessor)
        {
            this.actionContextAccessor = actionContextAccessor;
        }

        public string GetContainerName()
        {
            var rd = actionContextAccessor.ActionContext.RouteData;
            string currentController = rd.Values["controller"].ToString();
            var type = currentController switch
            {
                //"QueueDetails" => Environment.GetEnvironmentVariable("QueueDetailContainerName"),
                //"Results" => Environment.GetEnvironmentVariable("ResultContainerName"),
                //"RuleGroupResults" => Environment.GetEnvironmentVariable("RuleGroupResultContainerName"),
                //"FutureActions" => Environment.GetEnvironmentVariable("FutureActionContainerName"),
                _ => Environment.GetEnvironmentVariable("DictionaryContainerName"),
            };

            return type;
        }

    }
}
