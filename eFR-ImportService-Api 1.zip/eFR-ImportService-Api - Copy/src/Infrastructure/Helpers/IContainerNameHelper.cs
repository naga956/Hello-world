﻿namespace Infrastructure.Helpers
{
    public interface IContainerNameHelper
    {
        string GetContainerName();
    }
}
