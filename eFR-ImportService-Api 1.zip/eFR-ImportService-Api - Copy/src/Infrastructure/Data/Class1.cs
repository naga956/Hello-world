﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Data
{
    class Class1
    {
    }
}
