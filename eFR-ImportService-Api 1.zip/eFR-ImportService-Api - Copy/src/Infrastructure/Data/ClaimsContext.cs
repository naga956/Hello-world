﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Data
{
    public class DictionaryContext: DbContext
    {
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            if (modelBuilder == null)
            {
                throw new ArgumentNullException(nameof(modelBuilder));
            }

            modelBuilder.HasDefaultContainer(containerNameHelper.GetContainerName());
            //modelBuilder.Entity<Fact>();
            //modelBuilder.Entity<Queue>();
            //modelBuilder.Entity<Tenant>();
            //modelBuilder.Entity<TenantUser>();
            //modelBuilder.Entity<TenantRuleDbModel>();

            //modelBuilder.Entity<Product>();
            //modelBuilder.Entity<ProductModel>().OwnsMany(x => x.Facts);
            //modelBuilder.Entity<QueueUser>();

            //logger.LogInfo($"EFCore ConfigContext model created successfully {modelBuilder.Model}");
        }
    }
}
