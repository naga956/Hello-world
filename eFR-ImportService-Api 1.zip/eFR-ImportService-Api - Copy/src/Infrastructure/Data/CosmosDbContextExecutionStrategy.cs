﻿using Microsoft.EntityFrameworkCore.Storage;
using System;

namespace Infrastructure.Data
{
    public class CosmosDbContextExecutionStrategy : ExecutionStrategy
    {
        public CosmosDbContextExecutionStrategy(ExecutionStrategyDependencies dependencies, int maxRetryCount, TimeSpan maxRetryDelay)
            : base(dependencies, maxRetryCount, maxRetryDelay)
        {
        }

        protected override bool ShouldRetryOn(Exception exception)
        {
            return true;
        }
    }
}